
exports.handler = async (event) => {
    console.log('contact router', JSON.stringify(event));
    
    if (event.res.session.demo?.contact?.Yes_No === 'Yes' && !event.res.session.demo?.contact?.boterror) {
        return 'BasicName';
    }
    
    if (event.res.session.demo?.contact?.Yes_No === 'No' && !event.res.session.demo?.contact?.boterror) {
        return 'Thank you / Thanks / Bye / Goodbye / Exit / Close';
    }
    
    return 'BasicRestart';

    // return !event.res.session.demo?.contact?.Yes_No === 'Yes' || !event.res.session.demo?.name?.LastName || event.res.session.demo?.name?.boterror  ? 'BasicRestart' : 'BasicEmail';
    //   (SessionAttributes.demo.contact.Yes_No === "Yes" ) ? "BasicName" : (!SessionAttributes.demo.contact.Yes_No) ? "BasicRestart" : "Thank you / Thanks / Bye / Goodbye / Exit / Close"
};
