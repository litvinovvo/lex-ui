
exports.handler = async (event) => {
    console.log('name router', JSON.stringify(event));

    if (event.req?._event?.currentIntent?.slotDetails?.slot?.originalValue?.toLowerCase() === 'no') {
        return 'BasicName';
    }
    return !event.res.session.demo?.name?.FirstName || !event.res.session.demo?.name?.LastName || event.res.session.demo?.name?.boterror  ? 'BasicRestart' : 'BasicPhone';
    // (!SessionAttributes.demo.name.FirstName || !SessionAttributes.demo.name.FirstName) ? 'BasicRestart' :  'BasicPhone'
};
