exports.handler = async (event) => {
    console.log('phone router', JSON.stringify(event));

    return !event.res.session.demo?.phone?.PhoneNumber || event.res.session.demo?.phone?.boterror  ? 'BasicRestart' : 'BasicEmail';
    // (!SessionAttributes.demo.email.EmailAddress) ? 'BasicRestart' : 'BasicFinish'
};
