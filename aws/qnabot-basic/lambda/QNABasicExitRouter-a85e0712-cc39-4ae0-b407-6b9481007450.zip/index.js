exports.handler = async (event) => {
    const lastResponse = event.res.session.demo.last.FreeText;
    const routesMap = {
        exit: 'Thank you / Thanks / Bye / Goodbye / Exit / Close',
        start: 'Start / Help / Get Started / Hi / Go',
    };
    
    console.log('exit router', JSON.stringify(event));
    
    for (const route in routesMap) {
      if(!routesMap.hasOwnProperty(route)) {
        continue;
      }
      
      if (routesMap[route].toLowerCase().indexOf(lastResponse.toLowerCase()) !== -1) {
          return routesMap[route];
      }
    }

    return routesMap.exit;
};
