exports.handler=function(event,context,cb){
    event.res.card = {
            send: true,
            title: "Services",
            text: "",
            url: "",
            buttons: event.res.session.areas.map(area => ({ text: area, value: area })),
    };
    cb(null,event)
}