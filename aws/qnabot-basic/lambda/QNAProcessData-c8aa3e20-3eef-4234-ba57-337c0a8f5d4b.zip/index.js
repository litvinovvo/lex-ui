exports.handler = async function (event, context, callback) {
    const fetch = require("node-fetch");
    const FORM_SECRET = 'lincolnlabs';
    const data = event.res.session.demo;
    const endpoint = event.res.session.endpoint;
    const formId = event.res.session.form_id;
    const areas = event.res.session.areas;
    
    const postBotData = async () => {
        try {
            const req = await fetch(endpoint, {
                method: 'POST',
                body: new URLSearchParams({
                    form_id: formId,
                    form_args: JSON.stringify({
                        'your-name': data.name.FirstName,
                        'your-last-name': data.name.LastName,
                        'your-phone': data.phone.PhoneNumber,
                        'your-email': data.email.EmailAddress,
                        'your-subject': areas.find(area => area.toLowerCase() === data.service.FreeText.toLowerCase()),
                        
                    }),
                    secret: FORM_SECRET,
                })
            });
            
            if (req.status !== 200) {
                const error = new Error(`${req.status} ${req.statusText}`);

                throw error;
            }
        } catch (error) {
            console.error(error);
            event.res?.session?.appContext?.altMessages && (event.res.session.appContext.altMessages = {});
            event.res.message = "We've encountered an error while processing your answer. Please try again later.";
            return event;
        }
    }
    
    await postBotData();
    return event;
}