exports.handler = async (event) => {
    console.log('phone router', JSON.stringify(event));

    return !event.res.session.demo?.email?.EmailAddress || event.res.session.demo?.phone?.boterror  ? 'BasicRestart' : 'BasicFinish';
    // (!SessionAttributes.demo.email.EmailAddress) ? 'BasicRestart' : 'BasicFinish'
};
